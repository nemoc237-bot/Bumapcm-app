import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { collection, getDocs, query, orderBy, limit } from "firebase/firestore";
import { db } from "../firebase";
import { ListingCard } from "../components/ListingCard";
import { SearchBar } from "../components/SearchBar";

// Firestore has no native substring/"contains" search, so this pulls a
// recent batch of listings and filters client-side across title,
// description, and subcategory. Fine for a young marketplace; once the
// `listings` collection gets big, swap this for Algolia/Typesense/Meilisearch
// so search stays fast on slow Buea connections instead of downloading
// hundreds of docs per query.
const FETCH_LIMIT = 300;

function matches(listing, term) {
  const haystacks = [listing.title, listing.description, listing.subcategory];
  return haystacks.some((field) =>
    (field || "").toLowerCase().includes(term)
  );
}

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const rawQuery = searchParams.get("q") || "";
  const term = rawQuery.trim().toLowerCase();

  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!term) {
      setResults([]);
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError(null);

    async function runSearch() {
      try {
        const q = query(
          collection(db, "listings"),
          orderBy("createdAt", "desc"),
          limit(FETCH_LIMIT)
        );
        const snapshot = await getDocs(q);
        if (cancelled) return;
        const all = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        setResults(all.filter((listing) => matches(listing, term)));
      } catch (err) {
        if (!cancelled) setError(err.message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    runSearch();
    return () => {
      cancelled = true;
    };
  }, [term]);

  return (
    <div className="min-h-screen bg-stone-50 pb-8">
      <header className="px-4 pt-5 pb-2 bg-white border-b border-stone-100 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-sm text-stone-500 mb-1">
          ← Back
        </button>
        <h1 className="text-lg font-bold text-stone-900">
          {rawQuery ? `Results for: ${rawQuery}` : "Search BUMAP"}
        </h1>
      </header>

      <SearchBar initialValue={rawQuery} />

      <div className="px-4 pt-2">
        {loading && (
          <div className="flex flex-col gap-3 mt-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 rounded-2xl bg-stone-200 animate-pulse" />
            ))}
          </div>
        )}

        {!loading && error && (
          <p className="text-center text-red-600 text-sm mt-8">
            Couldn't search right now: {error}
          </p>
        )}

        {!loading && !error && !term && (
          <p className="text-center text-stone-500 text-sm mt-8">
            Type something above to search listings.
          </p>
        )}

        {!loading && !error && term && results.length === 0 && (
          <div className="text-center mt-12">
            <p className="text-stone-600 font-medium mb-3">
              No listings found for {rawQuery}. Be the first to post.
            </p>
            <button
              onClick={() => navigate("/post")}
              className="px-5 py-2.5 rounded-xl bg-[#1fb567] text-white text-sm font-semibold"
            >
              Post a Listing
            </button>
          </div>
        )}

        {!loading && !error && results.length > 0 && (
          <div className="flex flex-col gap-3 mt-2">
            {results.map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
