import { useState } from "react";
import { useNavigate } from "react-router-dom";

export function SearchBar({ initialValue = "" }) {
  const [term, setTerm] = useState(initialValue);
  const navigate = useNavigate();

  function runSearch() {
    const trimmed = term.trim();
    if (!trimmed) return;
    navigate(`/search?q=${encodeURIComponent(trimmed)}`);
  }

  return (
    <div className="px-4 pt-3 pb-1">
      <div className="flex items-center gap-2 bg-white rounded-xl shadow-sm border border-stone-100 px-3 py-2.5">
        <span className="text-stone-400">🔍</span>
        <input
          type="text"
          inputMode="search"
          value={term}
          onChange={(e) => setTerm(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && runSearch()}
          placeholder="Search BUMAP: Fufu, iPhone, Studio..."
          className="flex-1 bg-transparent text-sm text-stone-800 placeholder-stone-400 focus:outline-none"
        />
        {term && (
          <button
            onClick={runSearch}
            className="text-xs font-semibold text-[#1fb567] px-1"
            aria-label="Search"
          >
            Go
          </button>
        )}
      </div>
    </div>
  );
}
