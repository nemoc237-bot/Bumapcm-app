# BUMAP — Subcategory Navigation, Listings, Post Form + Global Search

## Files
- `src/data/categories.js` — single source of truth for category/subcategory labels + slugs (Food list updated, "Waakye" removed, "Khati Khati" spelling fixed)
- `src/firebase.js` — Firestore/Storage init (merge with your existing config, don't duplicate)
- `src/components/Card.jsx` — shared card shell
- `src/components/ListingCard.jsx` — the listing card used identically on ListingsPage and SearchPage
- `src/components/SearchBar.jsx` — the 🔍 search bar, used on Home and SearchPage
- `src/pages/Home.jsx` — homepage: header + search bar + Houses/Items/Services tiles
- `src/pages/SubcategoriesPage.jsx` — grid of subcategory cards for a given `?type`
- `src/pages/ListingsPage.jsx` — Firestore-backed listings grid for a given `?type&sub`
- `src/pages/SearchPage.jsx` — reads `?q`, searches listings, renders same card layout as ListingsPage
- `src/pages/PostForm.jsx` — post form with cascading Category → Subcategory dropdowns
- `src/App.jsx` — route wiring, including the new `/search` route

## Install
```
npm install firebase react-router-dom
```

## Firestore setup

**Two composite indexes needed** — Firestore will prompt with a console link the first time each query runs, or add manually:

1. Listings-by-category (`ListingsPage.jsx`):
   - Collection: `listings` — Fields: `type` (Asc), `subcategory` (Asc)

2. Search (`SearchPage.jsx`):
   - Collection: `listings` — Fields: `createdAt` (Desc)
   - (This one's just a single-field index, usually auto-created — but if `createdAt` is missing on any doc, that doc is silently excluded from search results and sorting.)

## How search works (and its limits)

Firestore has no native "contains" / full-text search. `SearchPage.jsx` pulls the **300 most recent** listings and filters client-side across `title`, `description`, and `subcategory` (case-insensitive `includes`). That's deliberately capped — Buea users are often on slow data, and downloading the whole collection on every keystroke-turned-search would be slow and expensive.

Tradeoffs to know:
- A very old listing outside the most-recent-300 window won't be found even if it matches. Fine for a young marketplace; revisit if `listings` grows past a few thousand docs.
- For real full-text search at scale, swap in **Algolia**, **Typesense**, or **Meilisearch** (all have Firebase Extensions that auto-sync on write) rather than growing this client-side filter.

## Adding a 4th homepage tile later
Everything (Subcategories grid, Post form dropdowns) reads from `CATEGORIES` / `SUBCATEGORIES` in `src/data/categories.js` — add a category there and it shows up everywhere automatically.

## Notes
- Mobile-first throughout: tiles are `grid-cols-2`/`grid-cols-3`, cards stack vertically, search bar and inputs are full-width with generous tap targets.
- Colors: primary `#1fb567` (BUMAP's real theme color), amber-500 for the Contact button as a secondary accent.
- `Home.jsx` only shows the header + search bar + Houses/Items/Services section — your existing "Browse by category" (Food/Groceries/Fashion/Electronics) and the payment/delivery/verification info cards go back in below, unchanged.
