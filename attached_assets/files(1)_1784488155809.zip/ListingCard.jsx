import { Card } from "./Card";

export function ListingCard({ listing }) {
  const { title, price, location, imageUrl, images, contact } = listing;
  const cover = imageUrl || images?.[0];

  return (
    <Card className="flex overflow-hidden">
      <div className="w-24 h-24 flex-shrink-0 bg-stone-100">
        {cover ? (
          <img src={cover} alt={title} className="w-full h-full object-cover" loading="lazy" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-stone-300 text-xs">
            No photo
          </div>
        )}
      </div>
      <div className="flex-1 p-3 flex flex-col justify-between min-w-0">
        <div>
          <h3 className="font-semibold text-stone-900 text-sm truncate">
            {title || "Untitled listing"}
          </h3>
          <p className="text-[#1fb567] font-bold text-sm mt-0.5">
            {price ? `${Number(price).toLocaleString()} FCFA` : "Price on request"}
          </p>
          <p className="text-stone-500 text-xs truncate">{location || "Buea"}</p>
        </div>
        {contact && (
          <a
            href={`tel:${contact}`}
            className="mt-2 self-start px-3 py-1.5 rounded-lg bg-amber-500 text-white text-xs font-semibold"
          >
            Contact
          </a>
        )}
      </div>
    </Card>
  );
}
