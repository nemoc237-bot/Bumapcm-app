import { useNavigate } from "react-router-dom";
import { Card } from "../components/Card";
import { SearchBar } from "../components/SearchBar";

// Icons/blurbs match what's already live on the BUMAP homepage.
const TILES = [
  { type: "house", label: "Houses", icon: "🏠", blurb: "Rooms for rent" },
  { type: "item", label: "Items", icon: "🛍️", blurb: "Phones, beds…" },
  { type: "service", label: "Services", icon: "🛠️", blurb: "Tailors, Graphics" },
];

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-stone-50 pb-10">
      <header className="px-4 pt-5 pb-2 bg-white">
        <h1 className="text-lg font-bold text-stone-900">🛒 BUMAP</h1>
        <p className="text-xs text-stone-500">Buea Market Place</p>
      </header>

      {/* TASK 2: global search bar, sits right under the header */}
      <SearchBar />

      <section className="mt-4">
        <h2 className="px-4 text-sm font-semibold text-stone-700 mb-2">
          Houses, Items & Services
        </h2>
        <div className="grid grid-cols-3 gap-3 px-4">
          {TILES.map((tile) => (
            <Card
              key={tile.type}
              onClick={() => navigate(`/subcategories?type=${tile.type}`)}
              className="p-4 flex flex-col items-center text-center gap-1"
            >
              <span className="text-3xl">{tile.icon}</span>
              <span className="font-semibold text-sm text-stone-800">{tile.label}</span>
              <span className="text-[11px] text-stone-500 leading-tight hidden sm:block">
                {tile.blurb}
              </span>
            </Card>
          ))}
        </div>
      </section>

      {/* Existing "Browse by category" (Food, Groceries, Fashion, Electronics)
          and the payment/delivery/verification info cards stay as-is below —
          this file only shows the parts this task touches. */}
    </div>
  );
}
