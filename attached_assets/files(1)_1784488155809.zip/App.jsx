import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import SubcategoriesPage from "./pages/SubcategoriesPage";
import ListingsPage from "./pages/ListingsPage";
import PostForm from "./pages/PostForm";
import SearchPage from "./pages/SearchPage";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/subcategories" element={<SubcategoriesPage />} />
        <Route path="/listings" element={<ListingsPage />} />
        <Route path="/post" element={<PostForm />} />
        {/* TASK 3: /search reads ?q from the URL inside SearchPage itself
            via useSearchParams, so no route param plumbing needed here. */}
        <Route path="/search" element={<SearchPage />} />
      </Routes>
    </BrowserRouter>
  );
}
