# BUMAP — All 7 Categories, Unified Listings Flow

## ⚠️ Read this first
I don't have your real `ListingsPage.jsx`, `CreateListingForm`, or Firestore field names — only the homepage JSX snippet and a screenshot you've shared. Everything here is built to be **consistent and drop-in-shaped**, but you'll need to reconcile it with what's actually deployed. Two things to check before merging:

1. **Field name: `type` vs `category`.** This build queries/writes `type` (matching earlier turns in this conversation). An earlier message of yours specified `category` instead. If your real Firestore docs already use `type`, you're fine. If they use `category`, find-replace `type` → `category` in the two Firestore calls inside `ListingsPage.jsx` (`LISTING_TYPE_FIELD` constant makes this a one-line change). Get this wrong and every Browse tab will silently show "no listings" — no error, just wrong data.

2. **The Sell tab's form is a stand-in.** If you have a real `CreateListingForm` component, replace `SellTab` in `ListingsPage.jsx` with `<CreateListingForm category={type} subcategory={sub} onPosted={...} />` — don't run both.

## What changed
- **`src/data/categories.js`** — `categoryData` now covers all 7 categories (house, item, service + food, groceries, fashion, electronics) in one object, same `{id, name, icon, desc}` shape you specified for the new 4.
- **`src/pages/ListingsPage.jsx`** — single component, reused by all 7 categories:
  - `/listings?type=food` (no `sub`) → subcategory grid
  - `/listings?type=food&sub=cooked-meals` → Browse/Sell tabs
  - Browse tab queries Firestore `listings` where `type == food AND subcategory == cooked-meals`
  - Sell tab posts a new doc with `type`, `subcategory` pre-filled from the URL (hidden, not editable) — matches your "auto set category and subcategory from URL" requirement
- **`src/pages/HomeSections.jsx`** — both homepage sections, restyled to match your screenshot exactly (plain white rounded cards, no colored backgrounds — the earlier colored-tile snippet doesn't match what's actually live). Food/Groceries/Fashion/Electronics tiles now link to `/listings?type=X` exactly like Houses/Items/Services already do.
- **`src/components/ListingCard.jsx`** — same white-card style.
- **`src/App.jsx`** — one `/listings` route handles everything; no separate `/food`, `/groceries` etc. routes needed, since the real app doesn't appear to use per-category routes either (Houses/Items/Services all go through `/listings?type=`).

## Test path
Home → Food → Cooked Meals → Sell tab → fill in "Plate of Eru" → Post Listing → auto-returns to Browse tab → listing appears (queries `type=food, subcategory=cooked-meals`, same doc that was just written).

## Still missing for a real merge
- Your actual `ListingsPage.jsx` source (to confirm the Browse/Sell tab mechanism instead of me inferring it)
- Your actual `CreateListingForm` (image upload, `userId` from auth, etc. — this stand-in only has a client-side field, no auth wiring)
- Confirmation on the `type` vs `category` field name above
