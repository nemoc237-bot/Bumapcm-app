import { categoryData } from "../data/categories";

// Matches the screenshot: plain white rounded cards, shadow, icon on top,
// bold label — no colored backgrounds. All 7 tiles now go through the same
// /listings?type=X flow (subcategory grid, then Browse/Sell tabs).

const BROWSE_BY_CATEGORY = ["food", "groceries", "fashion", "electronics"];
const HOUSES_ITEMS_SERVICES = [
  { type: "house", blurb: "Rooms for rent" },
  { type: "item", blurb: "Phones, beds…" },
  { type: "service", blurb: "Tailors, Graphics" },
];

function CategoryTile({ type }) {
  const cat = categoryData[type];
  return (
    <div
      onClick={() => (window.location.href = `/listings?type=${type}`)}
      className="bg-white rounded-2xl shadow p-4 text-center cursor-pointer border border-stone-100"
    >
      <div className="text-4xl">{cat.icon}</div>
      <p className="font-semibold mt-2 text-sm">{cat.name}</p>
    </div>
  );
}

export function HomeSections() {
  return (
    <>
      <div className="mt-8 px-4">
        <h2 className="text-xl font-bold mb-4">Browse by Category</h2>
        <div className="grid grid-cols-2 gap-3">
          {BROWSE_BY_CATEGORY.map((type) => (
            <CategoryTile key={type} type={type} />
          ))}
        </div>
      </div>

      <div className="mt-8 px-4">
        <h2 className="text-xl font-bold mb-4">Houses, Items & Services</h2>
        <div className="grid grid-cols-3 gap-3">
          {HOUSES_ITEMS_SERVICES.map(({ type, blurb }) => {
            const cat = categoryData[type];
            return (
              <div
                key={type}
                onClick={() => (window.location.href = `/listings?type=${type}`)}
                className="bg-white rounded-2xl shadow p-4 text-center cursor-pointer border border-stone-100"
              >
                <div className="text-4xl">{cat.icon}</div>
                <p className="font-semibold mt-2 text-sm">{cat.name}</p>
                <p className="text-xs text-gray-500 mt-0.5">{blurb}</p>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}
