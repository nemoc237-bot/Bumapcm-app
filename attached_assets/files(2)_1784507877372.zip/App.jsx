import { BrowserRouter, Routes, Route } from "react-router-dom";
import ListingsPage from "./pages/ListingsPage";
// import Home from "./pages/Home"; // renders <HomeSections /> from ./pages/HomeSections
// import PostForm from "./pages/PostForm"; // if you still want a standalone /post entry point

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* <Route path="/" element={<Home />} /> */}

        {/* One route handles all 7 categories: no ?sub -> subcategory grid,
            ?sub present -> Browse/Sell tabs. Covers what would otherwise be
            /food, /food/:subcategoryId, /groceries, etc. */}
        <Route path="/listings" element={<ListingsPage />} />

        {/* <Route path="/post" element={<PostForm />} /> */}
      </Routes>
    </BrowserRouter>
  );
}
